<?php
 require('conf/conbd.php');
//require('conf/connet.php');
?>