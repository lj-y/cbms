﻿<?PHP
session_start();
$cuser=$_SESSION['cuser'];
require('../conn.php');
$name = $_GET['adminname'];
$tel = $_GET['tel'];
$pass=$_GET['password'];
$password = md5($_GET['password']);
if(empty($name)){
echo '<script>alert("用户名不能为空，重新输入！");window.location.href="addadmin.php";</script>';
exit;}
if(empty($pass)){
echo '<script>alert("密码不能为空，重新输入！");window.location.href="addadmin.php";</script>';
exit;
}
//检测是否有添加管理员权限.
$sql="select * from  {$tableAdmin} where name='$cuser'";
$roles = mysqli_query($conn,$sql); 
$role = mysqli_fetch_array($roles);

if($role['role']==1||$role['role']==3){
$sql="select count(*)  as total from   $tableAdmin where name='$name'";
$result = mysqli_query($conn,$sql); 
$res = mysqli_fetch_array($result);
$num= $res['total'];
if($num==0){ 
$sql = "insert into  $tableAdmin (name, tel,password,role) values ('$name',  '$tel', '$password','05');";
$result = mysqli_query($conn,$sql); 
echo  "<script>window.location.href='adminList.php'</script>";
}else{ echo "<script>alert('存在相同用户名,重新输入');window.location.href='addAdmin.php'</script>";}
}//END if($role)
else{   echo '<script>alert("当前用户没有添加管理员权限！");window.location.href="adminList.php";</script>';
exit;}
//mysqli_free_result($roles);
//mysqli_free_result($result);
?>