<?php
require '../conn.php';
session_start();
$cuser =$_SESSION['cuser']; 
if(!isset($_SESSION['checked'])){echo "非法操作<a href='index.html' target='_parent'>立即返回</a>";exit();}
if(!$_SESSION['checked']){echo "不存在用户";exit();}
//if($_SESSION['cuser']!=$htuser){echo "当前用户没有会员管理权限。";exit();}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="/lib/bootstrap/css/bootstrap.min.css">  
<title>图书管理系统</title>
<style>
*{ margin:0 auto;    
padding:0px;
cellpadding:0px; 
cellspacing:0px;
border: 0px solid #7ff;
}

a{
text-decoration: none;
}

#page{ background: #C9F; text-align:center;}
body{ background-color:#9cc}
table{ 
	line-height:25px;
	position:absolute;
	top:50px;
	left:0px;
	background-color: #cccccc;
	text-align:left;
border-collapse:collapse;	
}

.xh{
 text-align:center;
}

table tr{
	height:15px; 	}
#ta1{ background-color:#CCC;}
span{ vertical-align:middle;}

</style>
<script type = "text/javascript" src = "../jqury/jquery.js" ></script>
</head>

<body>
<form action='adminList.php' method= 'get'>
<table width="680"  border="1px">
<tr  bgcolor="#9c6809">
<td width  = "50"  class = "xh" >序号</td>
<td width  = "80">用户名</td>
<td width  = "80">tel</td>
<td width="80">编辑</td>
<td width="80">删除</td>
</tr>

<?php 
if($cuser== 'admin' ){  $sql = "select * from {$tableAdmin}  order by name asc;";}
else{$sql = "select * from {$tableAdmin}  where not(name ='admin') order by name asc;";}
$result  = mysqli_query($con,$sql);
$i=1;
while(
	$row = mysqli_fetch_array($result)
){
if($i%2==0){echo '<tr  bgcolor="#F0FFF0">';}else{  echo  '<tr>' ;}	
?>

    <td class  = "xh"><?php echo $i++;?></td>
    <td class  = "bookname"><?php echo $row['name'];?></td>
    <td><?php echo $row['tel'];?></td>
    <td><a href="editAdmin.php?id=<?php echo $row['id']; ?>"  ><span class="glyphicon glyphicon-edit"></span></a></td>
    <td><a href="removeAdmin.php?name=<?php echo $row['name']; ?> "  onclick="return confirm('确定要删除用户[<?php echo $row["name"];?>]吗？')"><span class="glyphicon glyphicon-remove"></span></a></td>
</tr>

<?php
}
mysqli_free_result($result);
?>
</table>
</form>
<p>&nbsp;</p>
</body>
<script>
//全选 
function seall(){ $("input:checkbox").each(function () { this.checked = "true"; }) } 

function allno(){ $("input:checkbox").each(function () 
{ $(":checkbox").removeAttr("checked"); }) } 

function allnot(){ $("#fru>input:checkbox").each(function () { this.checked = !this.checked; }) } 

var tog = false ;
function sele(){
if(!tog ){ seall();}else { allno();}
tog = !tog;
}
</script>
</html>