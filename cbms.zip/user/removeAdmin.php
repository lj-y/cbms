<?php
require '../conn.php';
session_start();
$cuser=$_SESSION['cuser'];
$name=$_GET['name'];
if($name=="admin"){echo  "不可删除管理员admin <script>window.location.href='adminList.php'</script>";exit(); }
if(!isset($_SESSION['checked'])){echo "非法操作<a href='index.html' target='_parent'>立即返回</a>";exit();}
if(!$_SESSION['checked']){echo "不存在用户";exit();}
//if($_SESSION['cuser']!=$htuser){echo "当前用户没有会员管理权限。";exit();}
//检测是否有添加管理员权限.
$sql="select * from  {$tableAdmin} where name='$cuser'";
$roles = mysqli_query($conn,$sql); 
$role = mysqli_fetch_array($roles);

if($role['role']==2||$role['role']==1){
$sql = "delete from {$tableAdmin} where name='$name' ";
$result  = mysqli_query($conn,$sql);
if($result){ header('location:adminList.php');}
}//END if($role)
else{   echo '<script>alert("当前用户没有删除管理员权限！");window.location.href="adminList.php";</script>';
exit;}
mysqli_free_result($roles);

?>