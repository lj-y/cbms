﻿<?PHP
require '../conn.php';
session_start();
//if(!$_SESSION['checked']){echo "非法查询 <a href='index.html'>返回</a>";exit();}
if($_SESSION['cuser']!=$htuser){echo "<body style='background:#9cc'>当前会员无用户编辑权限！<a href='adminList.php'>返回</a></body>";exit();}
$id= $_GET['id'];
$sql = "select * from  $tableAdmin where id=$id" ;
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>编辑图书</title>
</head>
<body>
<form action="saveAdmin.php" method="get">
<table width="481" height="154" border="0">
  <tr>
    <td width="83">用户名：</td>
    <td width="267"><input name="adminname" type="text" value="<?php echo $row['name']; ?>"></td>
  </tr>
    <tr>
    <td width="83">tel：</td>
    <td width="267"><input name="tel" type="text" value="<?php echo $row['tel']; ?>"></td>
  </tr>
  
  <tr>
    <td>密码：</td>
    <td><input type="text"  name="password" value="<?php echo $row['password']; ?>"></td>
  </tr>
  <tr>
    <td>role：</td>
    <td><input type="text"  name="role" value="<?php echo $row['role']; ?>"></td>
  </tr>
  <tr>
    <td><input type="text" name="id" value="<?php echo $row['id'];?>"  ></td>
    <td><p><input type="submit" value="确定"></p></td>
  </tr>
</table>
</form>
<?php mysqli_free_result($result);?>
</body>
</html>