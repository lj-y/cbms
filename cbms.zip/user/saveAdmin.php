﻿<?PHP
session_start();
$cuser=$_SESSION['cuser'];
require('../conn.php');
$id= $_GET['id'];
$name = $_GET['adminname'];
$tel = $_GET['tel'];
$password = $_GET['password'];
$role = $_GET['role'];
//检测是否有添加管理员权限.
$sql="select * from  {$tableAdmin} where name='$cuser'";
$result = mysqli_query($con,$sql); 
$resc = mysqli_fetch_array($result);
if($resc['role']==1||$resc['role']==3){
$sql = "update $tableAdmin set name='$name',tel='$tel',password=md5('$password') ,role='$role' where id='$id';";
$res = mysqli_query($con,$sql);
echo "<script>window.location.href='adminList.php'</script>";
}else{    echo '<script>alert("当前用户没有管理员编辑权限！");window.location.href="addadmin.php";</script>';
exit();}

?>