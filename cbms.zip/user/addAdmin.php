﻿<?PHP
//require 'conn.php';
session_start();
if(!$_SESSION['checked']){echo "非法查询 <a href='right.php' >返回</a>";exit();}
//if($_SESSION['cuser']!=$htuser){echo "用户未经授权！ <a href='right.php' >返回</a>";exit();}
?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="/lib/bootstrap/css/bootstrap.min.css">  
<script src="/lib/jquery/jquery.js"></script>
<script src="/lib/bootstrap/js/bootstrap.min.js"></script>
<style>
body{ background-color:#9cc}
form{   
 margin-left:35px;margin-top:50px;
}
</style>
</head>
<body>
<form action="addAdminDo.php" method="get">
<table width="500" height="154" border="0">
  <tr>
    <td width="83">用户名：</td>
    <td width="196"><input name="adminname" type="text" value="" pattern ='[a-zA-Z][a-zA-Z0-9]{4,15}'></td>
    <td width=""><lable>以字母开头的5-15位字母数字组合</lable></td>
  </tr>
<tr>
    <td>密码：</td>
    <td><input type="text"  name="password" value="" pattern ='[a-zA-Z0-9]{5,8}'></td>
    <td width=""><lable>5-8位字母数字组合</lable></td>
</tr>
<tr>
    <td>tel：</td>
    <td><input type="text"  name="tel" value="" pattern="^1(3|4|5|7|8)\d{9}$"></td>
    <td width=""><lable>11位手机号码</lable></td>
</tr>
<tr>
    <td>Role：</td>
    <td><input type="text"  name="role" value="05"></td>
    <td width=""><lable>01-05范围中的一个数</lable></td>
</tr>

<tr>
    <td></td>
    <td><input type="submit" value="确定"></td>
     <td></td>
  </tr>
</table>
</form>
</body>
</html>