<?php
require '../conn.php';
session_start();
if(!isset($_SESSION['checked'])){echo "非法操作<a href='../index.html' target='_parent'>立即返回</a>";exit();}
if(!$_SESSION['checked']){echo "不存在用户";exit();}
if(!isset($_SESSION['gwc'])||  $_SESSION['gwc']==''){  
	echo "购物车为空,请先<a href = '../book/booklist.php'>添加商品</a>到购物车！";
	exit();
}
$cuser =$_SESSION['cuser']; 

if(isset($_GET['delId'])){$delId= $_GET['delId'];
if($delId=='emp'){ unset($_SESSION['gwc']); 
echo '<script>window.location.href ="cart.php";</script>';
exit(); 
}else{
	unset($_SESSION['gwc'][$delId]);
	}
}
$arr = $_SESSION['gwc'];
// foreach ($arr as $k=>$a) {
//     echo " $k $a[0] $a[1]|" ;
// }
// echo "<br>";
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="/lib/bootstrap/css/bootstrap.min.css">  
<script type = "text/javascript" src = "/lib/jquery/jquery.js" ></script>

<title>信息管理系统</title>
<style>
	*{ margin:0 auto;    
	padding:0px;
	cellpadding:0px; 
	cellspacing:0px;
	border: 0px solid #7ff;
	}
	a{text-decoration: none;}
	#page{ background: #C9F; text-align:center;}
	body{ background-color:#9cc}
	table{ 
		line-height:25px;
		position:absolute;
		top:50px;
		left:0px;
		background-color: #cccccc;
	    border-collapse:collapse;	
	}
	input{   width:80px;}
	table td{   
		border:0px solid red;
		width:80px;}
	div{ margin-top: 5%; }
	.first{   text-align: center;  }
	table tr{   height:15px; 	}
	#ta1{ background-color:#CCC;}
	span{  margin-left:10px}
</style>
<script type = "text/javascript" src = "/lib/jqury/jquery.js" ></script>
</head>
<body>
<form action='adminList.php' method= 'get'>
<table>
	<tr  bgcolor="#9c6809">
		<td  class = "first" >序 号</td>
		<td style="width:180px">ProductName</td>
		<td>Count</td>
		<td >Price</td>
		<td>TotalPrice</td>
		<td>Action</td>
	</tr>

<?php 
$i=1; $total=0;
// $k=0;
foreach ($arr as $k=>$a) {
	$sql = "select * from {$tableName} where name='{$a[0]}'; ";
	//echo '<br>'.$sql.
    echo '<br>';
	$result = mysqli_query($con,$sql);
	if($k%2==0){echo "<tr  bgcolor='#F0FFF0'>";}else{ echo "<tr background='#aaa'>";}
    $row = mysqli_fetch_assoc($result);
	// print_r($row);
	echo   "<td class='first'>"."&nbsp;&nbsp;&nbsp;".$i++."</td><td>$a[0] </td> ";
	echo '
	<td>
		<div style="width:80px">
			<input style="width: 15px; height: 20px; border: 2px white; float: left;" type="button" value="-" onclick="reductionOf(this)" />
			<input style="text-align: center; width: 30px; height: 20px; float: left;" 
					id="'.$k.'"
				type="text" value='.$a[1]. ' '.'onblur="checkNumber(this)" />
			<input  style="width: 15px; height: 20px; border: 2px white;" type="button" value="+"  onclick="add(this)" />
		</div>
	</td>';
	echo "<td><input type='text'  id='pri'   value=' ". $row['price'] ." '/></td>";
	echo "<td><input type='text' class='zj'  value=' ".$row['price']*$a[1] ." '/></td>
		  <td><a href='cart.php?delId=$k'>
		  <span class='glyphicon glyphicon-trash' title ='删除'></span></a></td>
	</tr>";
	$total += $row['price']*$a[1] ;
} // foreach
echo "<tr><td colspan='4' style='text-align:right'><a href='?delId=emp'>
<img src = '../images/cart2.png' title = '清空购物车'></a></td><td>合计总价：</td><td>$total</td></tr>";
if($result){mysqli_free_result($result);}
mysqli_close($con);
?>
</table>
</form>
<p>&nbsp;</p>
<script type="text/javascript">
//加减操作改变数量后更新总价合计
function change(){
	var sum=0;
	$.each($('table tr').find('td:eq(4) input'),function(){
		sum +=parseInt(this.value);
	});
	$('table tr:last td:last').text(sum);	 	
}

//减数量
function reductionOf(obj) {
	//发送数据，返回结果到合计总价
	//减前判断
	if ($(obj).next().val() == '') {
		$(obj).next().val(1);
	}
	var  txt =parseInt($(obj).next().val())- 1 ;//数值减
	txt=txt>0?txt:0;
	$(obj).next().val(txt);//赋值给框
	
	if ($(obj).next().val() <= '0') {
			$(obj).next().val(0);
	}
			
	var price=  $(obj).parents("tr").children("td").next().children("input").val();
	price = parseInt(price);
	//总价=单价*数量
	var zj = price*txt;
	$(obj).parent().parent().next().next().children("input").val(zj);
	change();
	//保留删除前更改的数量 发送id txt参数到gwc.php
    var id = $(obj).next().attr('id');
	$.ajax({
		type:"post",
		url: "gwc.php",
		dataType: "text",
		data:{ 'k':id, 'txt':txt}, //ids为$k与txt两个参数;
		success:function(res){   
		//alert(res);
		},
		error:function(){   
			// alert("error");
		}
	});
};

//加数量
function add(obj){
    //加前判断
   	if ($(obj).prev().val() == '') {
		$(obj).prev().val(1);
	}
	//数量
	var txt = parseInt( $(obj).prev().val() )+1 ;//数值加
    txt= parseInt(txt);
    $(obj).prev().val(txt);//赋值给框
	//单价
	var price=  $(obj).parents("tr").children("td").next().children("input").val();
	price = parseInt(price);
	var zj = price*txt;	//总价=单价*数量

	$(obj).parent().parent().next().next().children("input").val(zj);
    // $('.zj').val( $('#pri').val( )* txt );仅适用于一行
	change();
    var id = $(obj).prev().attr('id');
	$.ajax({
		type:"post",
		url: "gwc.php",
		dataType: "text",
		data:{ 'k':id, 'txt':txt}, //ids为$k与txt两个参数;
		success:function(res){   
               //alert(res);
		},
		error:function(){   
           //  alert("error");
        }
	});
}

//校验数字格式（只能输入正整数）
function checkNumber(obj) {
	var reg = /^[1-9]\d*$/;
	if(!reg.test($(obj).val()) || $(obj).val()==''){
		$(obj).val(1);
	}
}
</script>
</body>
</html>