<?php
session_start();
$k = $_POST['k'];
$txt = $_POST['txt'];
// echo $k.' '.$txt;
$_SESSION['gwc'][$k][1] = $txt;
// print_r($_SESSION['gwc'][$k]);
?>