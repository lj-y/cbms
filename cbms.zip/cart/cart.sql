-- phpMyAdmin SQL Dump
-- version 4.0.8
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2020-01-26 13:05:12
-- 服务器版本: 5.5.34
-- PHP 版本: 5.5.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `fy13`
--

-- --------------------------------------------------------

--
-- 表的结构 `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `Shop_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `User_id` varchar(30) NOT NULL,
  `ProductId` varchar(30) NOT NULL,
  `ProductName` varchar(30) NOT NULL,
  `Count` int(4) NOT NULL,
  `Price` double NOT NULL,
  PRIMARY KEY (`Shop_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `cart`
--

INSERT INTO `cart` (`Shop_id`, `User_id`, `ProductId`, `ProductName`, `Count`, `Price`) VALUES
(1, '1', '1', 'book1', 1, 10),
(2, '1', '5', 'book5', 2, 50);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;