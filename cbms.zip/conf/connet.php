<?php
	$host = "localhost";
	$db = 'fy13';
	$tableName='bookst';
	$user = 'fy13';
	$pwd =	'fy13';
	$htuser= 'admin';
	$tableAdmin='bookstadmin';
	$con = mysqli_connect($host,$user,$pwd,$db);
	mysqli_query($con,'set names utf8');
	if(!$con){ die("连接错误：".mysql_connect_error()); }
	error_reporting(0);
?>