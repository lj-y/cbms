-- phpMyAdmin SQL Dump
-- version 4.1.14.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2019-12-01 18:51:30
-- 服务器版本： 5.1.69
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fy13`
--

-- --------------------------------------------------------

--
-- 表的结构 `producest`
--
use fy13;
CREATE TABLE IF NOT EXISTS `producest` (
  `id_b` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET utf8 NOT NULL,
  `price` double NOT NULL,
  `isbn` varchar(30) NOT NULL,
  `user` varchar(30) NOT NULL,
  `img`  varchar(30) NOT NULL,
  `detail`  varchar(30) NOT NULL,
  PRIMARY KEY (`id_b`)
);

--
-- 转存表中的数据 `producest`
--

INSERT INTO `bookst` (`id_b`, `name`, `price`, `isbn`, `user`) VALUES
(1, 'produce1', 31, '9787001', 'admin'),
(2, 'produce2', 50, '97875601', 'admin'),
(3, 'produce3', 66, '97875601', 'admin'),
(4, 'produce4', 56, '97875601', 'admin'),
(5, 'produce5', 67, '978765130789', 'admin'),
(6, 'produce6', 67, '978765130789', 'admin'),
(7, 'produce7', 67, '978765130789', 'admin'),
(8, 'produce8', 67, '978765130789', 'admin'),
(9, 'produce9', 67, '978765130789', 'admin'),
(10, 'produce10', 66, '97875601', 'admin'),
(11, 'produce11', 66, '97875601', 'admin'),
(12, 'produce12', 31, '9787001', 'admin'),
(13, 'produce13', 50, '97875601', 'admin'),
(14, 'produce14', 66, '97875601', 'admin'),
(15, 'produce15', 66, '97875601', 'admin'),
(16, 'produce16', 66, '97875601', 'admin'),
(17, 'produce17', 66, '97875601', 'admin'),
(18, 'produce18', 66, '97875601', 'admin'),
(19, 'produce19', 56, '9787001', 'admin'),
(20, 'produce20', 56, '978765130789', 'admin');