<?php
session_start();
if(!isset($_SESSION['checked'])){echo "非法操作<a href='index.html' target='_parent'>立即返回</a>";exit();}
if(!$_SESSION['checked']){echo '不存在用户<a href="index.html">返回</a>';exit();}

require "../conn.php";
$path = "books.csv";
fopen("books.csv","w");
$open =  fopen("books.csv", "a");
$sql = "select * from {$tableName};";
$result  = mysqli_query($con,$sql);

while(
	$row = mysqli_fetch_array($result)
){  
	fwrite($open,$row['name'].",".$row['price'].",".
		$row['isbn'].",".$row['img'].",".$row['detail'].",".
		$row['user']."\n" );
}
echo '成功导出CSV文件,<a href="books.csv">点击下载</a>';
fclose($open);
mysqli_free_result($result);
?>