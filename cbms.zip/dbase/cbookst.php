<?php
require "../conn.php";
mysqli_query($con,"use fy13");
$sql ="CREATE TABLE IF NOT EXISTS `bookst` (
  `id_b` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET utf8 NOT NULL,
  `price` double NOT NULL,
  `isbn` varchar(30) NOT NULL,
  `user` varchar(30) NOT NULL,
  `img`  varchar(200) NOT NULL,
  `detail`  varchar(300) NOT NULL,
  PRIMARY KEY (`id_b`)
);";

if(mysqli_query($con,$sql)){  echo "ok";}else{ echo "error";}

?>