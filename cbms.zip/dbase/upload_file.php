<?php
session_start();
$cuser = $_SESSION['cuser'];
require '../conn.php';
header("Content_Type:text/html;charset=utf-8");
echo $_SERVER['PHP_SELF']."<br>";
$fname= $_FILES['myfile'];
//ove_uploaded_file($fname['tmp_name'], iconv("utf-8", "gb2312", "../upload/".$fname['name']));

if(file_exists("../upload/".$fname["name"])){
 echo $_FILES["file"]["name"]."文件已经存在,即将恢复";
}else{move_uploaded_file($fname['tmp_name'], "../upload/".$fname["name"]);}
echo "文件存储在".  " upload/"  .$fname['name'];
echo "请稍候, 等待跳转...";
$fnam = $fname['name'];
$hand = fopen("../upload/".$fnam, "r");
echo "<br>";
$line=1;
while($data=fgetcsv($hand,",") ){
	if($line++>0){
		$sql = "insert into $tableName(name,price,isbn,user)values('$data[0]','$data[1]','$data[2]','$cuser')";
		mysqli_query($con,$sql) or die(mysqli_error($con));
		}

}	
fclose($hand);
sleep(5);
header("refresh:3;url=..\book\booklist.php");
?>