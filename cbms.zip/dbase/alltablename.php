<?php 
require "../conn.php";
$result = mysqli_query($con,"SHOW TABLES");
while($row = mysqli_fetch_array($result))
{
echo $row[0]."<br>";
}
mysqli_free_result($result); 


?>