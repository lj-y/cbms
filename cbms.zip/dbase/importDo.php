<?php
require "../conn.php";
$str = file_get_contents("books.csv");
$a = explode("",$sql);
foreach($a as $b){
$c = $b.";";
mysqli_query($con,$c);
}
?>