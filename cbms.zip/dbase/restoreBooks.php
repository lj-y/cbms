<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		body{background-color: #9cc;}
	</style>
</head>
<body>
<?php
require "../conn.php";
//恢复数据前数据库是否为空
$sql = "select count(id_b) from $tableName";
$result = mysqli_query($con,$sql);
$res = mysqli_fetch_array($result);
// echo "<pre>";
// var_dump($res);
// echo "<pre>";
// echo $res[0];
// 	恢复原始数据
if( $res[0]== 0 ){
	$sql  = file_get_contents("original.sql");
	$a = explode(";",$sql);
	foreach($a as $b){@mysqli_query($con,$b);}
	echo '<script>alert("Restore Success! Wait...");window.location.href="../book/booklist.php";</script>';
}else{ echo "先清空数据库!";}
?>
</body>
</html>