-- phpMyAdmin SQL Dump
-- version 4.1.14.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2020-01-17 18:52:37
-- 服务器版本： 5.1.69
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fy13`
--

-- --------------------------------------------------------

--
-- 表的结构 `bookstadmin`
--
use fy13;
CREATE TABLE IF NOT EXISTS `bookstadmin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET ascii NOT NULL,
  `tel` text NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=78 ;

--
-- 转存表中的数据 `bookstadmin`
--

INSERT INTO `bookstadmin` (`id`, `name`, `tel`, `password`, `role`) VALUES
(23, 'admin', '13210531901', 'fb2c97e0afb532d0a6d9e6ee56dc6d2b', '01'),
(30, 'add', '13501056557', '21232f297a57a5a743894a0e4a801fc3', '05'),
(53, 'amd', '16653071606', '21232f297a57a5a743894a0e4a801fc3', '05'),
(52, 'del', '16653071613', '6ad4664ba23eac71b5ef5e826ea0c6cd', '05'),
(57, 'user', '16653071601', '21232f297a57a5a743894a0e4a801fc3', '05'),
(59, 'edit', '13500101353', 'c3284d0f94606de1fd2af172aba15bf3', '05'),
(74, 'user05', '15307256220', '29a4b79bd438555382de11012a82136e', '05');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
