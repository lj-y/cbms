<?php
require('conf/connet.php');
//updata password
$sql = "update $tableAdmin set name='admin',password=md5('admin')";
$res = mysqli_query($con,$sql);

?>