
<?php
require('../conn.php');
header("Content-type: text/html; charset=utf-8");
//如果是从detail.php则刷新页面
echo $id_b= $_POST['id_b'];
//echo "CurPage:".
$CurPage =$_GET['CurPage'];
$detail  = $_POST['detail'];

// // 保存图片到images目录
$file = $_FILES['file'];
$name = iconv('utf-8','gb2312//IGNORE',$file['name']);
echo "文件名：".$name ."<br>";
//无下句 上传的文件名乱码，在数据库乱码，有图片显示 
//有下句 上传的文件名乱码，在数据库正常显示，页面无图片显示。将乱码的文件名重命名后正常显示
// mysqli_query('set names utf8');
// 查到原图片
$sql = "select * from $tableName  where id_b=$id_b";
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
mysqli_free_result($result);
// echo $row['img'];
$img = $file['name']==''? $row['img']:$file['name'].'|'.$row['img'];
$sql = "update $tableName set img='$img',  detail='$detail'  where id_b='$id_b'";
$res = mysqli_query($con,$sql);
//mysqli_free_result($res);

// 上传图片
if(
	$_FILES["file"]["type"] == "image/gif"
	|| $_FILES["file"]["type"] == "image/png"
	|| $_FILES["file"]["type"] == "image/jpg"
	|| $_FILES["file"]["type"] == "image/jpeg"
	// && $_FILES["file"]["size"] < 20000
){
   if ($_FILES["file"]["error"] > 0){
	    echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
    }else{
	    echo "Upload: " . $_FILES["file"]["name"] . "<br />";
	    echo "Type: " . $_FILES["file"]["type"] . "<br />";
	    echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
	    echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";

	    if (file_exists("../images/" . $_FILES["file"]["name"])){
	      echo $_FILES["file"]["name"] . " already exists. ";
	    }else{
	      move_uploaded_file($_FILES["file"]["tmp_name"],
	      // "../images/" . $_FILES["file"]["name"]);
	      "../images/" . $name);
	      echo "Stored in: " . "../images/" . $_FILES["file"]["name"];
	    }
    }
}else{  echo "Invalid file";  }
echo "<script>alert('上传成功!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
?>
</body>
</html>
	
	
	
	
	
	